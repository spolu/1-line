#!/bin/sh

cp -R ../js .
cp ../icon_*.png .
